'''
KEYWORDS used-- report , off, profit
1. Ask coffee type
2. Ask denomination
3. Check entered denomination is sufficient for the coffee price?
4. Make coffee
-- Turn on and off machine
'''
logo='''
 ######   #######  ######## ######## ######## ########    ##     ##    ###     ######  ##     ## #### ##    ## ######## 
##    ## ##     ## ##       ##       ##       ##          ###   ###   ## ##   ##    ## ##     ##  ##  ###   ## ##       
##       ##     ## ##       ##       ##       ##          #### ####  ##   ##  ##       ##     ##  ##  ####  ## ##       
##       ##     ## ######   ######   ######   ######      ## ### ## ##     ## ##       #########  ##  ## ## ## ######   
##       ##     ## ##       ##       ##       ##          ##     ## ######### ##       ##     ##  ##  ##  #### ##       
##    ## ##     ## ##       ##       ##       ##          ##     ## ##     ## ##    ## ##     ##  ##  ##   ### ##       
 ######   #######  ##       ##       ######## ########    ##     ## ##     ##  ######  ##     ## #### ##    ## ######## 
'''
menu={
    "espresso":{
        "ingredients":{
            "water": 50,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte":{
        "ingredients":{
            "water": 200,
            "coffee": 24,
            "milk": 150,
        },
        "cost": 2.5,
    },
    "cappucino":{
        "ingredients":{
            "water": 250,
            "coffee": 24,
            "milk": 100,
        },
        "cost": 3.0,
    }
}
resources={
    "water": 300,
    "coffee": 200,
    "milk": 100,
}
def coins():
    """Returns the amount entered in denomination"""
    print("Please insert coins.")
    print()
    price = int(input("Enter how many quarters?"))*0.25
    price += int(input("Enter how many dimes?"))*0.10
    price += int(input("Enter how many nickles?"))*0.05
    price += int(input("Enter how many penniees?"))*0.01
    return price

def check_resources(order_ingredients):
    """Returns if the resources are sufficient or not for taken order."""
    for item in order_ingredients:
        if order_ingredients[item] > resources[item]:
            print("There are no enough resources in the machine.")
            print("Money refunded!.")
            return False
        else:
            return True

def transaction_details(order_price, drink_cost):
    """Returns True if the money entered is sufficient for the ordered coffee.
        Prints the message and excess money (if there).
    """
    if order_price >= drink_cost:
        change = round(order_price - drink_cost,2)
        print()
        print(f"Here is the change {change}")
        print()
        return True
    else:
        print()
        print("The amount you entered is not sufficient. Cash refunded!")
        print()
        return False
    
def coffee_prep(order_ingredients, drink_name):
    """Deducts the ingredients from resources."""
    for item in order_ingredients:
        resources[item] -= order_ingredients[item]
    print(f"Here is your {drink_name} ☕. Enjoy!")
    print()
 
profit = 0 
count = 0  
is_on = True
print(logo)
while is_on:
    order = input("What would you like to have ?(espresso/latte/cappucino) ")
    print()
    if order == 'off':
        is_on = False
    elif order == 'profit':
        print(f"The profit gained upto now is ${profit}, by selling {count} drinks.")
        print()
    elif order == 'report':
        print(f"Water quantity left is {resources['water']}ml.")
        print(f"Coffee quantity left is {resources['coffee']}gm.")
        print(f"Milk quantity left is {resources['milk']}ml.")
        print()
    else:
        drink = menu[order]
        print(f"The price of your coffee will be ${drink['cost']}")
        print()
        order_price = coins()
        if transaction_details(order_price, drink['cost']):
            profit += drink['cost']
            if check_resources(drink['ingredients']):
                coffee_prep(drink['ingredients'],order)
                count += 1
            else:
                profit -= drink['cost']